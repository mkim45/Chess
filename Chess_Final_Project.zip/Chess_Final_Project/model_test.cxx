#include "model.hxx"
#include <catch.hxx>

using namespace ge211;

// These pass with the starter code and should continue
// to pass.

///
/// Example of how to set up and use Test_access
///

struct Test_access
{
    Model& model;

    // Constructs a `Test_access` with a reference to the Model under test.
    explicit Test_access(Model&);
    // Sets the player at `posn` to `player`.
    void set_player(Model::Position posn, Player player);
    // Gives direct access to `model.next_moves_` so our tests can modify it:
    Move_map& next_moves();
};

///
/// Member function definitions for Test_access
///

Test_access::Test_access(Model& model)
        : model(model)
{ }

void
Test_access::set_player(Model::Position posn, Player player)
{
    model.board_[posn] = player;
}

Move_map&
Test_access::next_moves()
{
    return model.next_moves_;
}

TEST_CASE("initial state test")
{
    Model model(8,8);
    Test_access access(model);
    CHECK(model.turn() == Player::light); //check proper player turn
    for (int i = 0; i < model.board().width; i++) {
        for (int j = 0; j < model.board().height; j++) {
            if (j < 2) {
                if (j == 1) {
                    CHECK(model.get_piece_model({i,j}) == Piece::pawn);
                }
                CHECK(model[{i, j}] == Player::dark); //check proper player
            } else if (j >= 6) {
                if (j == 6) {
                    CHECK(model.get_piece_model({i,j}) == Piece::pawn);
                }
                CHECK(model[{i, j}] == Player::light);
            } else {
                CHECK(model[{i, j}] == Player::neither);
            }
        }
    }
    CHECK(model.get_piece_model({0, 0}) == Piece::rook); //check all pieces
    CHECK(model.get_piece_model({7, 0}) == Piece::rook);
    CHECK(model.get_piece_model({0, 7}) == Piece::rook);
    CHECK(model.get_piece_model({7, 7}) == Piece::rook);
    //CHECK(model.get_piece_model({1, 0}) == Piece::knight);
    //CHECK(model.get_piece_model({1, 7}) == Piece::knight);
    //CHECK(model.get_piece_model({6, 0}) == Piece::knight);
    //CHECK(model.get_piece_model({6, 7}) == Piece::knight);
    CHECK(model.get_piece_model({2, 0}) == Piece::bishop);
    CHECK(model.get_piece_model({2, 7}) == Piece::bishop);
    CHECK(model.get_piece_model({5, 0}) == Piece::bishop);
    CHECK(model.get_piece_model({5, 7}) == Piece::bishop);
    CHECK(model.get_piece_model({3, 0}) == Piece::queen);
    CHECK(model.get_piece_model({3, 7}) == Piece::queen);
    CHECK(model.get_piece_model({4, 0}) == Piece::king);
    CHECK(model.get_piece_model({4, 7}) == Piece::king);

    CHECK(model.is_game_over() == false); //game is not over
    CHECK(model.winner() == Player::neither); //no winner yet

    for (int i = 0; i < model.board().width; i++) {
        CHECK(access.next_moves()[{i, 6}] == Position_set{{i, 5}, {i, 4}});
    }

    CHECK(access.next_moves()[{0, 0}] == Position_set{}); //check no dark moves
    CHECK(access.next_moves()[{2, 0}] == Position_set{});
    CHECK(access.next_moves()[{3, 0}] == Position_set{});
    CHECK(access.next_moves()[{4, 0}] == Position_set{});
    CHECK(access.next_moves()[{0, 1}] == Position_set{});

    CHECK(access.next_moves()[{0, 7}] == Position_set{});
    //CHECK(access.next_moves()[{1, 7}] == Position_set{{0,5}, {2,5}});
    CHECK(access.next_moves()[{2, 7}] == Position_set{});
    CHECK(access.next_moves()[{3, 7}] == Position_set{});
    CHECK(access.next_moves()[{4, 7}] == Position_set{});
    CHECK(access.next_moves()[{5, 7}] == Position_set{});
    //CHECK(access.next_moves()[{6, 7}] == Position_set{{7,5}, {5,5}});
    CHECK(access.next_moves()[{7, 7}] == Position_set{});

    model.play_move({4,6}, {4,5}); //turn and switch players
    CHECK(model.turn() == Player::dark);
    CHECK(model[{4,6}] == Player::neither);
    CHECK(model.get_piece_model({4,6}) == Piece::neither);
    CHECK(model[{4,5}] == Player::light);
    CHECK(model.get_piece_model({4,5}) == Piece::pawn);
    CHECK(model.winner() == Player::neither);
    CHECK(model.is_game_over() == false);

    for (int i = 0; i < model.board().width; i++) {
        CHECK(access.next_moves()[{i, 1}] == Position_set{{i, 2}, {i, 3}});
    }

    CHECK(access.next_moves()[{0, 7}] == Position_set{}); //check no light moves
    CHECK(access.next_moves()[{2, 7}] == Position_set{});
    CHECK(access.next_moves()[{3, 7}] == Position_set{});
    CHECK(access.next_moves()[{4, 7}] == Position_set{});
    CHECK(access.next_moves()[{0, 6}] == Position_set{});

    CHECK(access.next_moves()[{0, 0}] == Position_set{});
    //CHECK(access.next_moves()[{1, 0}] == Position_set{{0,5}, {2,5}});
    CHECK(access.next_moves()[{2, 0}] == Position_set{});
    CHECK(access.next_moves()[{3, 0}] == Position_set{});
    CHECK(access.next_moves()[{4, 0}] == Position_set{});
    CHECK(access.next_moves()[{5, 0}] == Position_set{});
    //CHECK(access.next_moves()[{6, 0}] == Position_set{{7,5}, {5,5}});
    CHECK(access.next_moves()[{7, 0}] == Position_set{});
}

TEST_CASE("pawn all moves tested")
{
    Model model(8,8);
    Test_access access(model);
    CHECK(model.turn() == Player::light); //check proper player turn
    CHECK(model.is_game_over() == false); //game is not over
    CHECK(model.winner() == Player::neither); //no winner yet

    CHECK(access.next_moves()[{0,6}] == Position_set{{0,5},
                                                     {0,4}});

    model.play_move({0, 6}, {0, 4});
    model.play_move({7, 1}, {7, 2});
    model.play_move({0, 4}, {0, 3});
    model.play_move({7, 2}, {7, 3});
    model.play_move({0, 3}, {0, 2});

    CHECK(access.next_moves()[{0,6}] == Position_set{});

    model.play_move({7, 3}, {7, 4});

    CHECK(access.next_moves()[{0,2}] == Position_set{{1,1}});
    model.play_move({0, 2}, {1, 1});
    model.play_move({7, 4}, {7, 5});

    CHECK(model.get_piece_model({1,1}) == Piece::pawn);
    model.play_move({1, 1}, {0, 0});
    model.play_move({7, 5}, {6, 6});

    CHECK(model.get_piece_model({0,0}) == Piece::queen);
}

TEST_CASE("knight all moves tested")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    CHECK(access.next_moves()[{1, 7}] == Position_set{{0, 5},
                                                      {2, 5}});
    model.play_move({1, 7}, {2, 5});
    model.play_move({7, 1}, {7, 2});

    CHECK(access.next_moves()[{2, 5}] == Position_set{{0, 4},
                                                      {1, 3},
                                                      {1, 7},
                                                      {3, 3},
                                                      {4, 4}});
    model.play_move({2, 5}, {1, 7});
    model.play_move({7, 2}, {7, 3});

    model.play_move({1, 7}, {2, 5});
    model.play_move({7, 3}, {7, 4});

    model.play_move({2, 5}, {3, 3});
    model.play_move({7, 4}, {7, 5});

    CHECK(access.next_moves()[{3, 3}] == Position_set{{1, 2},
                                                      {1, 4},
                                                      {2, 1},
                                                      {2, 5},
                                                      {4, 1},
                                                      {4, 5},
                                                      {5, 2},
                                                      {5, 4}});

    model.play_move({3,3}, {4,1});
    model.play_move({0,1}, {0,2});

    CHECK(access.next_moves()[{4,1}] == Position_set{{2, 0},
                                                     {2,2},
                                                     {3,3},
                                                     {5,3},
                                                     {6,0},
                                                     {6,2}});

    model.play_move({4, 1}, {6,0});
    model.play_move({0,2}, {0,3});
    model.play_move({6, 0}, {5,2});

    CHECK(access.next_moves()[{3,1}] == Position_set{});
    CHECK(access.next_moves()[{3,0}] == Position_set{{5,2}});
}

TEST_CASE("bishop all moves tested")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    CHECK(access.next_moves()[{2, 7}] == Position_set{});
    model.play_move({1,6}, {1,5});
    model.play_move({7,1}, {7,2});

    CHECK(access.next_moves()[{2, 7}] == Position_set{{1,6},
                                                    {0,5}});

    model.play_move({2,7}, {0,5});
    model.play_move({7,2}, {7,3});

    CHECK(access.next_moves()[{0,5}] == Position_set{{1,4},
                                                     {1,6},
                                                     {2,3},
                                                     {2,7},
                                                     {3,2},
                                                     {4,1}});

    model.play_move({0,5}, {4,1});
    model.play_move({7,3}, {7,4});

    CHECK(access.next_moves()[{4,1}] == Position_set{{0,5},
                                                     {1,4},
                                                     {2,3},
                                                     {3,0},
                                                     {3,2},
                                                     {5,0},
                                                     {5,2},
                                                     {6,3},
                                                     {7,4}});

    model.play_move({4,6}, {4,5});
    model.play_move({3,1}, {3,2});
    model.play_move({5,7}, {1,3});

    CHECK(access.next_moves()[{1,1}] == Position_set{});
    CHECK(access.next_moves()[{2,1}] == Position_set{{2,2}});

}


TEST_CASE("rook all moves tested")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    CHECK(access.next_moves()[{0, 7}] == Position_set{});
    model.play_move({0, 6}, {0, 4});
    model.play_move({0, 1}, {0, 3});

    CHECK(access.next_moves()[{0, 7}] == Position_set{{0, 5},
                                                      {0, 6}});
    model.play_move({0, 7}, {0, 5});
    model.play_move({1, 1}, {1, 2});

    CHECK(access.next_moves()[{0, 5}] == Position_set{{0,7},
                                                      {0,6},
                                                      {1, 5},
                                                      {2, 5},
                                                      {3, 5},
                                                      {4, 5},
                                                      {5, 5},
                                                      {6, 5},
                                                      {7, 5}});

    model.play_move({0, 5}, {4, 5});
    model.play_move({4,1}, {4,2});
    model.play_move({4,5}, {4,4});
    model.play_move({4,2}, {4,3});
    CHECK(access.next_moves()[{4, 4}] == Position_set{{1,4},
                                                      {2,4},
                                                      {3,4},
                                                      {4,3},
                                                      {4,5},
                                                      {5,4},
                                                      {6,4},
                                                      {7,4}});
    model.play_move({4,4}, {4,3});
    CHECK(access.next_moves()[{3, 0}] == Position_set{{4,1}});


};
TEST_CASE("queen all moves tested")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    CHECK(access.next_moves()[{3, 7}] == Position_set{});
    model.play_move({3,6}, {3,4});
    model.play_move({7,1}, {7,2});

    CHECK(access.next_moves()[{3, 7}] == Position_set{{3,5},
                                                      {3,6}});
    model.play_move({3,7}, {3,5});
    model.play_move({7,2}, {7,3});

    CHECK(access.next_moves()[{3, 5}] == Position_set{{0,2},
                                                      {0,5},
                                                      {1,3},
                                                      {1,5},
                                                      {2,4},
                                                      {2,5},
                                                      {3,6},
                                                      {3,7},
                                                      {4,4},
                                                      {4,5},
                                                      {5,3},
                                                      {5,5},
                                                      {6,2},
                                                      {6,5},
                                                      {7,1},
                                                      {7,5}});

    model.play_move({3,5}, {5,5});
    model.play_move({0,1}, {0,2});
    model.play_move({5,5}, {7,3});

    CHECK(access.next_moves()[{5,1}] == Position_set{});
}

TEST_CASE("king all moves tested")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    CHECK(access.next_moves()[{4, 7}] == Position_set{});
    model.play_move({4,6}, {4,4});
    model.play_move({3,1}, {3,2});

    CHECK(access.next_moves()[{4, 7}] == Position_set{{4,6}});
    model.play_move({0,6}, {0,5});
    model.play_move({2,0}, {6,4});

    CHECK(access.next_moves()[{4, 7}] == Position_set{});
    model.play_move({7,6}, {7,5});
    model.play_move({6,4}, {7,5});

    CHECK(access.next_moves()[{4, 7}] == Position_set{{4,6}});
    model.play_move({4,7}, {4,6});
    model.play_move({1,1}, {1,2});
    model.play_move({4,6}, {4,5});
    model.play_move({1,2}, {1,3});

    CHECK(access.next_moves()[{4, 5}] == Position_set{{3,4},
                                                      {3,5},
                                                      {4,6},
                                                      {5,4},
                                                      {5,5}});
}


TEST_CASE("king under check capture")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    model.play_move({0,6}, {0,5});
    model.play_move({7,1}, {7,3});
    model.play_move({0,5}, {0,4});
    model.play_move({7,0}, {7,2});
    model.play_move({0,4}, {0,3});
    model.play_move({7,2}, {4,2});
    model.play_move({5,6}, {5,5});
    model.play_move({4,2}, {4,6});

    CHECK(access.next_moves()[{4, 7}] == Position_set{{4,6}});
    model.play_move({4,7}, {4,6});
    model.play_move({0,1}, {0,2});
    model.play_move({4,6}, {4,7});
    model.play_move({6,1}, {6,2});
    CHECK(access.next_moves()[{4, 7}] == Position_set{{4,6},
                                                      {5,6}});
}

TEST_CASE("king under check move piece")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    model.play_move({0,6}, {0,5});
    model.play_move({7,1}, {7,3});
    model.play_move({0,5}, {0,4});
    model.play_move({7,0}, {7,2});
    model.play_move({0,4}, {0,3});
    model.play_move({7,2}, {4,2});
    model.play_move({5,6}, {5,5});
    model.play_move({4,2}, {4,6});

    CHECK(access.next_moves()[{4, 7}] == Position_set{{4,6}});
    model.play_move({5,7}, {4,6});
    model.play_move({6,1}, {6,2});
    CHECK(access.next_moves()[{4, 7}] == Position_set{{5,6},
                                                      {5,7}});
}

TEST_CASE("king checkmate")
{
    Model model(8, 8);
    Test_access access(model);
    CHECK(model.turn() == Player::light);
    CHECK(model.is_game_over() == false);
    CHECK(model.winner() == Player::neither);

    model.play_move({5,6}, {5,5});
    model.play_move({4,1}, {4,2});
    model.play_move({6,6}, {6,4});
    model.play_move({3,0}, {7,4});

    CHECK(model.is_game_over() == true);
    CHECK(model.winner() == Player::dark);

}

