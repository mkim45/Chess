/*******************************************/
/*** DO NOT CHANGE ANYTHING IN THIS FILE ***/
/*******************************************/

#include "board.hxx"
#include <algorithm>

using namespace ge211;

Board::Board(Dimensions dims)
        : dims_(dims)
{
    if (dims_.width < 2 || dims_.height < 2) {
        throw Client_logic_error("Board::Board: dims too small");
    }

    if (dims_.width > Position_set::coord_limit ||
        dims_.height > Position_set::coord_limit) {
        throw Client_logic_error("Board::Board: dims too large");
    }
}

void
Board::initial_state()
{
    for (int i = 0; i < dims_.width; i++) {
        for (int j = 0; j < 2; j++) {
            if (j == 1) {
                pawn_[{i, j}] = true;
            }
            dark_[{i, j}] = true;
        }
    }
    for (int i = 0; i < dims_.width; i++) {
        for (int j = 6; j < 8; j++) {
            if (j == 6) {
                pawn_[{i, j}] = true;
            }
            light_[{i, j}] = true;
        }
    }
    rook_[{0,0}] = true;
    rook_[{0,7}] = true;
    rook_[{7,7}] = true;
    rook_[{7,0}] = true;
    bishop_[{2,0}] = true;
    bishop_[{5,0}] = true;
    bishop_[{2,7}] = true;
    bishop_[{5,7}] = true;
    queen_[{3,0}] = true;
    queen_[{3,7}] = true;
    king_[{4,0}] = true;
    king_[{4,7}] = true;
    knight_[{1,0}] = true;
    knight_[{6,0}] = true;
    knight_[{1,7}] = true;
    knight_[{6,7}] = true;
}

Board::Dimensions
Board::dimensions() const
{
    return dims_;
}

bool
Board::good_position(Position pos) const
{
    return 0 <= pos.x && pos.x < dims_.width &&
           0 <= pos.y && pos.y < dims_.height;
}

Player
Board::operator[](Position pos) const
{
    bounds_check_(pos);
    return get_(pos);
}

Board::reference
Board::operator[](Position pos)
{
    bounds_check_(pos);
    return reference(*this, pos);
}

size_t
Board::count_player(Player player) const
{
    switch (player) {
    case Player::light:
        return light_.size();
    case Player::dark:
        return dark_.size();
    default:
        return dims_.width * dims_.height -
               light_.size() - dark_.size();
    }
}

static std::vector<Board::Dimensions>
build_directions()
{
    std::vector<Board::Dimensions> result;

    for (int dx = -1; dx <= 1; ++dx) {
        for (int dy = -1; dy <= 1; ++dy) {
            if (dx || dy) {
                result.push_back({dx, dy});
            }
        }
    }

    return result;
}

Board::Position
Board::get_king(Player play)
{
    for (Position p : king_) {
        if (get_(p) == play) {
            return p;
        }
    }
    return {-1, -1};
}

Position_set
Board::get_pawn(Player play)
{
    Position_set returner = {};
    for (Position p : pawn_) {
        if (get_(p) == play) {
            returner[p] = true;
        }
    }
    return returner;
}

std::vector<Board::Dimensions> const&
Board::all_directions()
{
    static std::vector<Dimensions> result = build_directions();
    return result;
}

std::vector<Board::Dimensions> Board::knight_directions() const
{
    std::vector<Dimensions> result;
    result.push_back({2, 1});
    result.push_back({2, -1});
    result.push_back({-2, 1});
    result.push_back({-2, -1});
    result.push_back({1, 2});
    result.push_back({1, -2});
    result.push_back({-1, 2});
    result.push_back({-1, -2});
    return result;
}

Position_set
Board::get_player_color(Player player)
{
    if (player == Player::light) {
        return light_;
    } else {
        return dark_;
    }
}

Board::Rectangle
Board::all_positions() const
{
    return Rectangle::from_top_left(the_origin, dims_);
}

bool
operator==(Board const& b1, Board const& b2)
{
    return b1.dims_ == b2.dims_ &&
           b1.light_ == b2.light_ &&
           b1.dark_ == b2.dark_ &&
           b1.pawn_ == b2.pawn_ &&
           b1.knight_ == b2.knight_ &&
           b1.bishop_ == b2.bishop_ &&
           b1.rook_ == b2.rook_ &&
           b1.queen_ == b2.queen_ &&
           b1.king_ == b2.king_;
}

Player
Board::get_(Position pos) const
{
    if (dark_[pos]) {
        return Player::dark;
    } else if (light_[pos]) {
        return Player::light;
    } else {
        return Player::neither;
    }
}

Piece
Board::get_piece_(Position pos) const
{
    if (pawn_[pos]) {
        return Piece::pawn;
    } else if (knight_[pos]) {
        return Piece::knight;
    } else if (bishop_[pos]) {
        return Piece::bishop;
    } else if (rook_[pos]) {
        return Piece::rook;
    } else if (queen_[pos]) {
        return Piece::queen;
    } else if (king_[pos]) {
        return Piece::king;
    } else {
        return Piece::neither;
    }
}

void
Board::set_(Position pos, Player player)
{
    switch (player) {
    case Player::dark:
        dark_[pos] = true;
        light_[pos] = false;
        break;

    case Player::light:
        dark_[pos] = false;
        light_[pos] = true;
        break;

    default:
        dark_[pos] = false;
        light_[pos] = false;
    }
}

void
Board::set_piece_(Position pos, Piece piece)
{
    switch (piece) {
    case Piece::pawn:
        pawn_[pos] = true;
        knight_[pos] = false;
        bishop_[pos] = false;
        rook_[pos] = false;
        queen_[pos] = false;
        king_[pos] = false;
        break;
    case Piece::knight:
        pawn_[pos] = false;
        knight_[pos] = true;
        bishop_[pos] = false;
        rook_[pos] = false;
        queen_[pos] = false;
        king_[pos] = false;
        break;
    case Piece::bishop:
        pawn_[pos] = false;
        knight_[pos] = false;
        bishop_[pos] = true;
        rook_[pos] = false;
        queen_[pos] = false;
        king_[pos] = false;
        break;
    case Piece::rook:
        pawn_[pos] = false;
        knight_[pos] = false;
        bishop_[pos] = false;
        rook_[pos] = true;
        queen_[pos] = false;
        king_[pos] = false;
        break;
    case Piece::queen:
        pawn_[pos] = false;
        knight_[pos] = false;
        bishop_[pos] = false;
        rook_[pos] = false;
        queen_[pos] = true;
        king_[pos] = false;
        break;
    case Piece::king:
        pawn_[pos] = false;
        knight_[pos] = false;
        bishop_[pos] = false;
        rook_[pos] = false;
        queen_[pos] = false;
        king_[pos] = true;
        break;
    default:
        pawn_[pos] = false;
        knight_[pos] = false;
        bishop_[pos] = false;
        rook_[pos] = false;
        queen_[pos] = false;
        king_[pos] = false;
    }
}

void
Board::set_all(Position_set pos_set, Player player)
{
    switch (player) {
    case Player::light:
        light_ |= pos_set;
        dark_ &= ~pos_set;
        break;

    case Player::dark:
        dark_ |= pos_set;
        light_ &= ~pos_set;
        break;

    default:
        dark_ &= ~pos_set;
        light_ &= ~pos_set;
    }
}

void
Board::set_all_piece(Position_set pos_set, Piece piece)
{
    switch (piece) {
    case Piece::pawn:
        pawn_ |= pos_set;
        knight_ &= ~pos_set;
        bishop_ &= ~pos_set;
        rook_ &= ~pos_set;
        queen_ &= ~pos_set;
        king_ &= ~pos_set;
        break;
    case Piece::knight:
        pawn_ &= ~pos_set;
        knight_ |= pos_set;
        bishop_ &= ~pos_set;
        rook_ &= ~pos_set;
        queen_ &= ~pos_set;
        king_ &= ~pos_set;
        break;
    case Piece::bishop:
        pawn_ &= ~pos_set;
        knight_ &= ~pos_set;
        bishop_ |= pos_set;
        rook_ &= ~pos_set;
        queen_ &= ~pos_set;
        king_ &= ~pos_set;
        break;
    case Piece::rook:
        pawn_ &= ~pos_set;
        knight_ &= ~pos_set;
        bishop_ &= ~pos_set;
        rook_ |= pos_set;
        queen_ &= ~pos_set;
        king_ &= ~pos_set;
        break;
    case Piece::queen:
        pawn_ &= ~pos_set;
        knight_ &= ~pos_set;
        bishop_ &= ~pos_set;
        rook_ &= ~pos_set;
        queen_ |= pos_set;
        king_ &= ~pos_set;
        break;
    case Piece::king:
        pawn_ &= ~pos_set;
        knight_ &= ~pos_set;
        bishop_ &= ~pos_set;
        rook_ &= ~pos_set;
        queen_ &= ~pos_set;
        king_ |= pos_set;
        break;
    default:
        pawn_ &= ~pos_set;
        knight_ &= ~pos_set;
        bishop_ &= ~pos_set;
        rook_ &= ~pos_set;
        queen_ &= ~pos_set;
        king_ &= ~pos_set;
    }
}

Piece
Board::get_piece(Position pos) const
{
    return get_piece_(pos);
}

void
Board::bounds_check_(Position pos) const
{
    if (!good_position(pos)) {
        throw Client_logic_error("Board: position out of bounds");
    }
}

bool
operator!=(Board const& b1, Board const& b2)
{
    return !(b1 == b2);
}

std::ostream&
operator<<(std::ostream& os, Board const& board)
{
    Board::Dimensions dims = board.dimensions();

    for (int y = 0; y < dims.height; ++y) {
        for (int x = 0; x < dims.width; ++x) {
            os << board[{x, y}];
        }
        os << "\n";
    }

    return os;
}

Board::reference::reference(Board& board, Position pos) noexcept
        : board_(board),
          pos_(pos)
{ }

Board::reference&
Board::reference::operator=(reference const& that) noexcept
{
    *this = Player(that);
    return *this;
}

Board::reference&
Board::reference::operator=(Player player) noexcept
{
    board_.set_(pos_, player);
    return *this;
}

Board::reference&
Board::reference::operator=(Piece piece) noexcept
{
    board_.set_piece_(pos_, piece);
    return *this;
}

Board::reference::operator Player() const noexcept
{
    return board_.get_(pos_);
}



