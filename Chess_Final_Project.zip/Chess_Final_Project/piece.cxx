//
// Created by Michael Kim on 5/21/22.
//

#include "piece.hxx"

/*******************************************/
/*** DO NOT CHANGE ANYTHING IN THIS FILE ***/
/*******************************************/

std::ostream&
operator<<(std::ostream& os, Piece p)
{
    switch (p) {
    case Piece::pawn:
        return os << "P";
    case Piece::knight:
        return os << "Kn";
    case Piece::bishop:
        return os << "B";
    case Piece::rook:
        return os << "R";
    case Piece::queen:
        return os << "Q";
    case Piece::king:
        return os << "K";
    default:
        return os << "_";
    }
}