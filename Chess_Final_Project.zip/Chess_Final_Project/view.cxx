#include "view.hxx"

// Convenient type aliases:
using Color = ge211::Color;
using Sprite_set = ge211::Sprite_set;

static ge211::Color const black_color {0, 0, 0};
static ge211::Color const white_color {255, 255, 255};
static ge211::Color const red_color {250, 80, 80};
static ge211::Color const light_color {250, 200, 140};
static ge211::Color const dark_color {180, 85, 55};

// You can change this or even determine it some other way:
static int const grid_size = 36;


View::View(Model const& model)
        : model_(model),
          tile_sprite_light_({grid_size - 2, grid_size - 2},
                             light_color),
          tile_sprite_dark_({grid_size - 2, grid_size - 2},
                            dark_color),
          tile_sprite_capture_({grid_size - 2, grid_size - 2},
                               red_color),
          fake_move_sprite_black_(((grid_size / 2) / 2) - 2,
                                  black_color),
          fake_move_sprite_white_(((grid_size / 2) / 2) - 2,
                                  white_color),
          image_pawn_white_("pawn_white.png"),
          image_pawn_black_("pawn_black.png"),
          image_knight_white_("knight_white.png"),
          image_knight_black_("knight_black.png"),
          image_bishop_white_("bishop_white.png"),
          image_bishop_black_("bishop_black.png"),
          image_rook_white_("rook_white.png"),
          image_rook_black_("rook_black.png"),
          image_queen_white_("queen_white.png"),
          image_queen_black_("queen_black.png"),
          image_king_white_("king_white.png"),
          image_king_black_("king_black.png")
{ }

void View::draw(Sprite_set& set, ge211::Posn<int> position, ge211::Posn<int>
        pos_two, bool check)
{
    bool checker = false;
    if (model_.is_game_over()) {
        checker = true;
    }
    // find a way to get the original starting/store pieces already here
    //View::Position position_view = board_to_screen(position);
    View::Position position_view_2 = board_to_screen(pos_two);
    for (int i = 0; i < model_.board().width; i++) {
        for (int j = 0; j < model_.board().height; j++) {
            if (i % 2 == 0) {
                if (j % 2 == 0) {
                    set.add_sprite(tile_sprite_light_,
                                   board_to_screen({0 +
                                                    i,
                                                    0 + j}),
                                   0);
                } else {
                    set.add_sprite(tile_sprite_dark_,
                                   board_to_screen({0 +
                                                    i,
                                                    0 + j}),
                                   0);
                }
            } else {
                if (j % 2 == 0) {
                    set.add_sprite(tile_sprite_dark_,
                                   board_to_screen({0 +
                                                    i,
                                                    0 + j}),
                                   0);
                } else {
                    set.add_sprite(tile_sprite_light_,
                                   board_to_screen({0 +
                                                    i,
                                                    0 + j}),
                                   0);
                }
            }
            add_player_sprite_(set, model_[{i, j}],
                               {i, j}, 3);
        }
    }
    if (!checker) {
        const Move* mover = model_.find_move(pos_two, position);
        Player play = model_.turn();
        if (mover != nullptr) {
            for (Position p : mover->second) {
                if (play == Player::dark) {
                    set.add_sprite(fake_move_sprite_black_,
                                   {board_to_screen(p).x + 10,
                                    board_to_screen(p).y + 10},
                                   2);
                } else if (play == Player::light) {
                    set.add_sprite(fake_move_sprite_white_,
                                   {board_to_screen(p).x + 10,
                                        board_to_screen(p).y + 10},
                                        2);
                }
            }
        }
        if (!check) {
            set.add_sprite(tile_sprite_capture_, position_view_2, 1);
        }
    }
}

View::Dimensions
View::initial_window_dimensions() const
{
    // You can change this if you want:
    return grid_size * model_.board().dimensions();
}

std::string
View::initial_window_title() const
{
    // You can change this if you want:
    return "Reversi";
}

View::Position
View::board_to_screen(Model::Position pos) const
{
    return {grid_size * pos.x, grid_size * pos.y};
}

Model::Position
View::screen_to_board(View::Position pos) const
{
    return {pos.x / grid_size, pos.y / grid_size};
}

void
View::add_player_sprite_(
        Sprite_set& set,
        Player player,
        Position pos,
        int z) const
{
    if (!model_.is_game_over()) {
        if (player == Player::dark) {
            if (model_.get_piece_model(pos) == Piece::pawn) {
                set.add_sprite(image_pawn_black_, {board_to_screen(pos).x + 1,
                                             board_to_screen(pos).y + 1}, z);
            } else if (model_.get_piece_model(pos) == Piece::knight) {
                set.add_sprite(image_knight_black_, {board_to_screen(pos).x + 1,
                                               board_to_screen(pos).y + 1}, z);
            } else if (model_.get_piece_model(pos) == Piece::bishop) {
                set.add_sprite(image_bishop_black_, {board_to_screen(pos).x + 1,
                                               board_to_screen(pos).y + 1}, z);
            } else if (model_.get_piece_model(pos) == Piece::rook) {
                set.add_sprite(image_rook_black_, {board_to_screen(pos).x + 1,
                                             board_to_screen(pos).y + 1}, z);
            } else if (model_.get_piece_model(pos) == Piece::queen) {
                set.add_sprite(image_queen_black_, {board_to_screen(pos).x + 1,
                                              board_to_screen(pos).y + 1}, z);
            } else if (model_.get_piece_model(pos) == Piece::king) {
                set.add_sprite(image_king_black_, {board_to_screen(pos).x + 1,
                                             board_to_screen(pos).y + 1}, z);
            }
        } else {
            if (player == Player::light) {
                if (model_.get_piece_model(pos) == Piece::pawn) {
                    set.add_sprite(image_pawn_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                } else if (model_.get_piece_model(pos) == Piece::knight) {
                    set.add_sprite(image_knight_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                } else if (model_.get_piece_model(pos) == Piece::bishop) {
                    set.add_sprite(image_bishop_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                } else if (model_.get_piece_model(pos) == Piece::rook) {
                    set.add_sprite(image_rook_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                } else if (model_.get_piece_model(pos) == Piece::queen) {
                    set.add_sprite(image_queen_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                } else if (model_.get_piece_model(pos) == Piece::king) {
                    set.add_sprite(image_king_white_,
                                   {board_to_screen(pos).x + 1,
                                    board_to_screen(pos).y + 1},
                                   z);
                }
            }
        }
    }
}

