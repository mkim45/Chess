//
// Created by Michael Kim on 5/21/22.
//

/*******************************************/
/*** DO NOT CHANGE ANYTHING IN THIS FILE ***/
/*******************************************/

#pragma once

#include <iostream>

// A player or lack thereof.
enum class Piece
{
    pawn,
    knight,
    bishop,
    rook,
    queen,
    king,
    neither
};




