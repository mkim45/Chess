#include "controller.hxx"

Controller::Controller(int size)
        : Controller(size, size)
{ }

Controller::Controller(int width, int height)
        : model_(width, height),
          view_(model_),
          Mouse_position_(width/2, height/2),
          clicker_(0),
          special_position_(-1, -1),
          turn_checker_(true)
{ }

void
Controller::draw(ge211::Sprite_set& sprites)
{
    view_.draw(sprites, view_.screen_to_board(Mouse_position_), view_
    .screen_to_board(special_position_), turn_checker_);
}

View::Dimensions
Controller::initial_window_dimensions() const
{
    return view_.initial_window_dimensions();
}

std::string
Controller::initial_window_title() const
{
    return view_.initial_window_title();
}

void
Controller::on_mouse_move(ge211::Posn<int> position)
{
    Mouse_position_ = position;
}

void
Controller::on_mouse_up(ge211::Mouse_button, ge211::Posn<int> position)
{
    if (model_.get_piece_model(view_.screen_to_board(position)) !=
    Piece::neither &&
    model_[view_.screen_to_board(position)] == model_.turn()) {
        if (clicker_ == 1) {
            clicker_ = 0;
            special_position_ = {-1, -1};
            turn_checker_ = true;
        } else {
            clicker_ = 1;
            special_position_ = position;
            turn_checker_ = false;
            //make sure that draw in view will light this square up
        }
    } else {
        if (clicker_ == 1) {
            if (model_[view_.screen_to_board(position)] != model_.turn()) {
                model_.play_move(view_.screen_to_board(special_position_), view_
                .screen_to_board(position));
                turn_checker_ = true;
                clicker_ = 0;
                special_position_ = {-1, -1};
            } else {
                clicker_ = 0;
                turn_checker_ = true;
                special_position_ = {-1, -1};
            }
        }
    }
}


