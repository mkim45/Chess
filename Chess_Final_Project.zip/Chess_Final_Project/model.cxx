#include "model.hxx"

using namespace ge211;

Model::Model(int size)
        : Model(size, size)
{ }

Model::Model(int width, int height)
        : board_({width, height}),
          recent_move_(-1, -1),
          black_under_check_(false),
          white_under_check_(false)
{
    board_.initial_state();
    compute_next_moves_();
    // TODO: initialize `next_moves_` to `turn_`'s available moves
}

Model::Rectangle
Model::board() const
{
    return board_.all_positions();
}

Player
Model::operator[](Position pos) const
{
    return board_[pos];
}

Piece
Model::get_piece_model(Position pos) const
{
    return board_.get_piece(pos);
}

const Move*
Model::find_move(Position pos, Position pos_two) const
{
    auto i = next_moves_.find(pos);
    if (i == next_moves_.end()) {
        // Nothing was found, so return NULL (nullptr in C++)
        return nullptr;
    } else {
        return &(*i);
        // Dereferences the iterator to get the value then returns a pointer
        // to that value. This is safe as the pointer is to a value living
        // within the `next_moves_` structure.
    }
}

void
Model::play_move(Position pos, Position pos_two)
{
    if (is_game_over()) {
        throw Client_logic_error("Model::play_move: game over");
    }
    const Move* movep = find_move(pos, pos_two);
    if (movep == nullptr) { // check if there was no such move
        throw Client_logic_error("Model::play_move: no such move");
    }
    bool check = false;
    for (Position p : movep->second) {
        if (p == pos_two) {
            check = true;
        }
    }
    if (check) {
        really_play_move_(*movep, pos_two, &(board_));
    } else {
        throw Client_logic_error("Model::play_move: no such move");
    }
    // TODO: actually execute the move, advance the turn, refill
    // `next_moves_`, etc.
}

//
// BELOW ARE HELPER FUNCTIONS
// Our tests will run on the public functions, not the helper functions
// However, you are required to implement the following functions to help the
// public functions
//

Position_set
Model::pawn_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        if (player == Player::light) {
            Position checker = {current.x, current.y - 1};
            if (board_.good_position(checker) && board_[checker]
                                                 == Player::neither) {
                returner[checker] = true;
                if (current.y == 6) {
                    checker = {checker.x, checker.y - 1};
                    if (board_.good_position(checker) && board_[checker] ==
                                                         Player::neither) {
                        returner[checker] = true;
                    }
                }
            }
            checker = {current.x - 1, current.y - 1};
            if (board_.good_position(checker) && board_[checker] == other_player
                    (player)) {
                returner[checker] = true;
                //this step takes a player
            }
            checker = {current.x + 1, current.y - 1};
            if (board_.good_position(checker) && board_[checker] == other_player
                    (player)) {
                returner[checker] = true;
                //this step takes a player
            }
        } else {
            if (player == Player::dark) {
                Position checker = {current.x, current.y + 1};
                if (board_.good_position(checker) && board_[checker]
                                                     == Player::neither) {
                    returner[checker] = true;
                    if (current.y == 1) {
                        checker = {checker.x, checker.y + 1};
                        if (board_.good_position(checker) && board_[checker] ==
                                                             Player::neither) {
                            returner[checker] = true;
                        }
                    }
                }
                checker = {current.x - 1, current.y + 1};
                if (board_.good_position(checker) && board_[checker] == other_player
                        (player)) {
                    returner[checker] = true;
                    //this step takes a player
                }
                checker = {current.x + 1, current.y + 1};
                if (board_.good_position(checker) && board_[checker] == other_player
                        (player)) {
                    returner[checker] = true;
                    //this step takes a player
                }
            }
        }
    }
    return returner;
}

Position_set
Model::knight_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Position checker = current;
        for (Dimensions dir : board_.knight_directions()) {
            checker = current;
            checker += dir;
            bool check = true;
            while (board_.good_position(checker) && check) {
                if (board_[checker] == Player::neither) {
                    returner[checker] = true;
                    checker += dir;
                    check = false;
                } else if (board_[checker] == other_player(player)) {
                    returner[checker] = true;
                    //this step takes a player
                    check = false;
                } else {
                    check = false;
                }
            }
        }
    }
    return returner;
}

Position_set
Model::bishop_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Position checker = current;
        for (Dimensions dir : board_.all_directions()) {
            checker = current;
            if (dir.width != 0 && dir.height != 0) {
                checker += dir;
                bool check = true;
                while(board_.good_position(checker) && check) {
                    if (board_[checker] == Player::neither) {
                        returner[checker] = true;
                        checker += dir;
                    } else if (board_[checker] == other_player(player)) {
                        returner[checker] = true;
                        //this step takes a player
                        check = false;
                    } else {
                        check = false;
                    }
                }
            }
        }
    }
    return returner;
}

Position_set
Model::rook_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Position checker = current;
        for (Dimensions dir : board_.all_directions()) {
            checker = current;
            if (dir.width == 0 || dir.height == 0) {
                checker += dir;
                bool check = true;
                while(board_.good_position(checker) && check) {
                    if (board_[checker] == Player::neither) {
                        returner[checker] = true;
                        checker += dir;
                    } else if (board_[checker] == other_player(player)) {
                        returner[checker] = true;
                        //this step takes a player
                        check = false;
                    } else {
                        check = false;
                    }
                }
            }
        }
    }
    return returner;
}

Position_set
Model::queen_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Position checker = current;
        for (Dimensions dir : board_.all_directions()) {
            checker = current;
            checker += dir;
            bool check = true;
            while(board_.good_position(checker) && check) {
                if (board_[checker] == Player::neither) {
                    returner[checker] = true;
                    checker += dir;
                } else if (board_[checker] == other_player(player)) {
                    returner[checker] = true;
                    //this step takes a player
                    check = false;
                } else {
                    check = false;
                }
            }
        }
    }
    return returner;
}

Position_set
Model::king_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Position checker = current;
        for (Dimensions dir : board_.all_directions()) {
            checker = current;
            checker += dir;
            bool check = true;
            while(board_.good_position(checker) && check) {
                if (board_[checker] == Player::neither) {
                    returner[checker] = true;
                    check = false;
                } else if (board_[checker] == other_player(player)) {
                    returner[checker] = true;
                    //this step takes a player
                    check = false;
                } else {
                    check = false;
                }
            }
        }
    }
    return returner;
}

Position_set
Model::possible_moves_(Position current, Player player) const
{
    Position_set returner = {};
    if (board_.good_position(current)) {
        Piece piece = board_.get_piece(current);
        if (piece == Piece::pawn) {
            returner = pawn_moves_(current, player);
        } else if (piece == Piece::knight) {
            returner = knight_moves_(current, player);
        } else if (piece == Piece::bishop) {
            returner = bishop_moves_(current, player);
        } else if (piece == Piece::rook) {
            returner = rook_moves_(current, player);
        } else if (piece == Piece::queen) {
            returner = queen_moves_(current, player);
        } else {
            return returner;
        }
    }
    return returner;
}

void
Model::compute_next_moves_()
{
    Move_map checking;
    Move_map other_moves;
    if (turn_ == Player::light) {
        white_under_check_ = false;
    } else {
        black_under_check_ = false;
    }

    Position king_finder = board_.get_king(turn_);
    if (!next_moves_.empty()) {
        Position_set initial_check = possible_moves_(recent_move_, other_player(turn_));
        next_moves_[recent_move_] = initial_check;
        for (Move m : next_moves_) {
            for (Position p : m.second) {
                if (p == king_finder) {
                    if (turn_ == Player::light) {
                        white_under_check_ = true;
                    } else {
                        black_under_check_ = true;
                    }
                    checking[m.first] = m.second;
                }
            }
        }
    }
    other_moves = next_moves_;
    //we have move set for all moves checking the king from other player
    next_moves_.clear();
    Player player = turn_;
    Position_set returner = {};
    Position_set opposite = {};
    int iterator = 0;
    Position_set illegal = {};
    Position_set target = {};
    Move_map targeter;
    Position_set more_illegal = {};
    bool test_check = false;
    for (Position p : board_.get_player_color(player)) {
        returner = possible_moves_(p, turn_);
        if (!returner.empty()) {
            next_moves_[p] = returner;
        }
    }
    Position_set returner2;
    //we have all moves if king under check and our move making king under
    // check wasn't an issue
    if (!checking.empty()) {
        Move_map tester;
        returner = king_moves_(king_finder, turn_);
        returner2 = returner;
        for (Move m : checking) {
            for (Position p : m.second) {
                for (Position p2 : returner2) {
                    if (p == p2) {
                        returner[p2] = false;
                    }
                    if (board_.get_piece(m.first) == Piece::rook) {
                        if (m.first.x == king_finder.x) {
                            if (p2.x == m.first.x) {
                                returner[p2] = false;
                            }
                        } else if (m.first.y == king_finder.y) {
                            if (p2.y == m.first.y) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m.first) == Piece::bishop) {
                        if (m.first.x > king_finder.x && m.first.y > king_finder.y) {
                            if (p2.x == king_finder.x - 1 && p2.y == king_finder.y - 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x < king_finder.x && m.first.y > king_finder.y) {
                            if (p2.x == king_finder.x + 1 && p2.y == king_finder.y - 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x < king_finder.x && m.first.y < king_finder.y) {
                            if (p2.x == king_finder.x + 1 && p2.y == king_finder.y + 1) {
                                returner[p2] = false;
                            }
                        } else {
                            if (p2.x == king_finder.x - 1 && p2.y == king_finder.y + 1) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m.first) == Piece::queen) {
                        if (m.first.x > king_finder.x && m.first.y > king_finder.y) {
                            if (p2.x == king_finder.x - 1 && p2.y == king_finder.y - 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x < king_finder.x && m.first.y > king_finder.y) {
                            if (p2.x == king_finder.x + 1 && p2.y == king_finder.y - 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x < king_finder.x && m.first.y < king_finder.y) {
                            if (p2.x == king_finder.x + 1 && p2.y == king_finder.y + 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x > king_finder.x && m.first.y < king_finder.y){
                            if (p2.x == king_finder.x - 1 && p2.y == king_finder.y + 1) {
                                returner[p2] = false;
                            }
                        } else if (m.first.x == king_finder.x) {
                            if (p2.x == m.first.x) {
                                returner[p2] = false;
                            }
                        } else if (m.first.y == king_finder.y) {
                            if (p2.y == m.first.y) {
                                returner[p2] = false;
                            }
                        }
                    }
                    if (p2 == m.first) {
                        returner[p2] = true;
                    }
                    for (Move m3 : other_moves) {
                        if (board_.get_piece(m3.first) == Piece::pawn) {
                            if (board_[m3.first] == Player::light) {
                                Position position_test = {m3.first.x + 1, m3.first.y - 1};
                                if (position_test == p2) {
                                    returner[p2] = false;
                                }
                                position_test = {m3.first.x - 1, m3.first.y - 1};
                                if (position_test == p2) {
                                    returner[p2] = false;
                                }
                            } else {
                                Position position_test = {m3.first.x + 1, m3.first.y + 1};
                                if (position_test == p2) {
                                    returner[p2] = false;
                                }
                                position_test = {m3.first.x - 1, m3.first.y + 1};
                                if (position_test == p2) {
                                    returner[p2] = false;
                                }
                            }
                        } else {
                            if (board_.get_piece(m3.first) == Piece::rook) {
                                for (Position p5 : m3.second) {
                                    if (p5 == p2) {
                                        returner[p2] = false;
                                    }
                                }
                            } else if (board_.get_piece(m3.first) == Piece::bishop) {
                                if (abs(p2.x - m3.first.x) == abs(p2.y - m3.first.y)) {
                                    returner[p2] = false;
                                }
                            } else if (board_.get_piece(m3.first) == Piece::queen) {
                                for (Position p5 : m3.second) {
                                    if (abs(p2.x - m3.first.x) == abs(p2.y - m3.first.y)) {
                                        returner[p2] = false;
                                    } else if (p5 == p2) {
                                        returner[p2] = false;
                                    }
                                }
                            } else if (board_.get_piece(m3.first) == Piece::knight) {
                                for (Position p5 : m3.second) {
                                    if (p5 == p2) {
                                        returner[p2] = false;
                                    }
                                }
                            } else if (board_.get_piece(m3.first) == Piece::king) {
                                for (Position p5 : m3.second) {
                                    if (p5 == p2) {
                                        returner[p2] = false;
                                    }
                                }
                            }
                        }
                    }
                }
                for (Move m2 : next_moves_) {
                    for (Position p3 : m2.second) {
                        if (p3 == m.first) {
                            opposite[p3] = true;
                        }
                        if (board_.get_piece(m.first) == Piece::bishop) {
                            if (m.first.x > king_finder.x && m.first.y > king_finder.y) {
                                if (p.y < m.first.y && p.x < m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y < king_finder.y) {
                                if (p.y > m.first.y && p.x > m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y > king_finder.y) {
                                if (p.y < m.first.y && p.x > m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else {
                                if (p.y > m.first.y && p.x < m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            }
                        } else if (board_.get_piece(m.first) == Piece::rook) {
                            if (m.first.x > king_finder.x && m.first.y == king_finder.y) {
                                if (p.y == m.first.y && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y == king_finder.y) {
                                if (p.y == m.first.y && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x == king_finder.x && m.first.y > king_finder.y) {
                                if (p.x == m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else {
                                if (p.x == m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            }
                        } else if (board_.get_piece(m.first) == Piece::queen) {
                            if (m.first.x > king_finder.x && m.first.y == king_finder.y) {
                                if (p.y == m.first.y && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y == king_finder.y) {
                                if (p.y == m.first.y && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x == king_finder.x && m.first.y > king_finder.y) {
                                if (p.x == m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x == king_finder.x && m.first.y < king_finder.y){
                                if (p.x == m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x > king_finder.x && m.first.y > king_finder.y) {
                                if (p.y < m.first.y && p.x < m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y < king_finder.y) {
                                if (p.y > m.first.y && p.x > m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else if (m.first.x < king_finder.x && m.first.y > king_finder.y) {
                                if (p.y < m.first.y && p.x > m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            } else {
                                if (p.y > m.first.y && p.x < m.first.x && p3 == p) {
                                    opposite[p3] = true;
                                }
                            }
                        }
                    }
                    if (!opposite.empty()) {
                        tester[m2.first] = opposite;
                        opposite.clear();
                    }
                }
            }
        }
        for (Move m3 : other_moves) {
            for (Position p2 : returner2) {
                if (board_.get_piece(m3.first) == Piece::pawn) {
                    if (board_[m3.first] == Player::light) {
                        Position position_test = {m3.first.x + 1, m3.first.y - 1};
                        if (position_test == p2) {
                            returner[p2] = false;
                        }
                        position_test = {m3.first.x - 1, m3.first.y - 1};
                        if (position_test == p2) {
                            returner[p2] = false;
                        }
                    } else {
                        Position position_test = {m3.first.x + 1, m3.first.y + 1};
                        if (position_test == p2) {
                            returner[p2] = false;
                        }
                        position_test = {m3.first.x - 1, m3.first.y + 1};
                        if (position_test == p2) {
                            returner[p2] = false;
                        }
                    }
                } else {
                    if (board_.get_piece(m3.first) == Piece::rook) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::bishop) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::queen) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::knight) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::king) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    }
                }
            }
        }
        for (Move m5 : other_moves) {
            iterator = 0;
            target.clear();
            test_check = false;
            if (board_.get_piece(m5.first) == Piece::rook) {
                if (m5.first.x == king_finder.x) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.x == king_finder.x) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                    if (iterator > 0) {
                        for (Position p7 : target) {
                            Position_set tester = rook_moves_(p7, other_player(turn_));
                            for (Position p6 : tester) {
                                if (p6 == king_finder) {
                                    test_check = true;
                                }
                            }
                            if (test_check) {
                                if (targeter[p7].empty()) {
                                    for (Position p9 : possible_moves_(p7, turn_)) {
                                        if (m5.first.x == king_finder.x) {
                                            if (p9.x == m5.first.x) {
                                                illegal[p9] = true;
                                            }
                                        } else if (m5.first.y == king_finder.y) {
                                            if (p9.y == m5.first.y) {
                                                illegal[p9] = true;
                                            }
                                        }
                                    }
                                    targeter[p7] = illegal;
                                } else {
                                    more_illegal[p7] = true;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        }
                    }
                } else if (m5.first.y == king_finder.y) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.y == king_finder.y) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                    if (iterator > 0) {
                        for (Position p7 : target) {
                            Position_set tester = rook_moves_(p7, other_player(turn_));
                            for (Position p6 : tester) {
                                if (p6 == king_finder) {
                                    test_check = true;
                                }
                            }
                            if (test_check) {
                                if (targeter[p7].empty()) {
                                    for (Position p9 : possible_moves_(p7, turn_)) {
                                        if (m5.first.x == king_finder.x) {
                                            if (p9.x == m5.first.x) {
                                                illegal[p9] = true;
                                            }
                                        } else if (m5.first.y == king_finder.y) {
                                            if (p9.y == m5.first.y) {
                                                illegal[p9] = true;
                                            }
                                        }
                                    }
                                    targeter[p7] = illegal;
                                } else {
                                    more_illegal[p7] = true;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        }
                    }
                }
            } else if (board_.get_piece(m5.first) == Piece::bishop) {
                if (abs(king_finder.x - m5.first.x) == abs(king_finder.y - m5.first.y)) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && abs(king_finder.x - p5.x)
                                                                            == abs(king_finder.y - p5.y)) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                }
                if (iterator > 0) {
                    for (Position p7 : target) {
                        Position_set tester = bishop_moves_(p7, other_player(turn_));
                        for (Position p6 : tester) {
                            if (p6 == king_finder) {
                                test_check = true;
                            }
                        }
                        if (test_check) {
                            if (targeter[p7].empty()) {
                                for (Position p9 : possible_moves_(p7, turn_)) {
                                    if (m5.first.x > king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x > king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    }
                                }
                                targeter[p7] = illegal;
                            } else {
                                more_illegal[p7] = true;
                            }
                        } else {
                            more_illegal[p7] = true;
                        }
                    }
                }
            } else if (board_.get_piece(m5.first) == Piece::queen) {
                if (m5.first.x == king_finder.x) {
                    for (Position p5: m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.x == king_finder.x) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                } else if (abs(king_finder.x - m5.first.x) == abs(king_finder.y - m5.first.y)) {
                    for (Position p5: m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king &&
                            abs(king_finder.x - p5.x) == abs(king_finder.y - p5.y)) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                }
                if (iterator > 0) {
                    for (Position p7 : target) {
                        Position_set tester = queen_moves_(p7, other_player(turn_));
                        for (Position p6 : tester) {
                            if (p6 == king_finder) {
                                test_check = true;
                            }
                        }
                        if (test_check) {
                            if (targeter[p7].empty()) {
                                for (Position p9 : possible_moves_(p7, turn_)) {
                                    if (m5.first.x > king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x > king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x == king_finder.x) {
                                        if (p9.x == m5.first.x) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.y == king_finder.y) {
                                        if (p9.y == m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    }
                                }
                                targeter[p7] = illegal;
                            } else {
                                more_illegal[p7] = true;
                            }
                        } else {
                            more_illegal[p7] = true;
                        }
                    }
                }
            }
        }
        next_moves_.clear();
        for (Move m10 : tester) {
            next_moves_[m10.first] = m10.second;
        }
        for (Move m11 : targeter) {
            next_moves_[m11.first] = m11.second;
        }
        for (Position p8 : more_illegal) {
            next_moves_[p8] = {};
        }
        tester.clear();
        if (!returner.empty()) {
            next_moves_[king_finder] = returner;
        }
    } else {
        returner = king_moves_(king_finder, turn_);
        returner2 = returner;
        for (Position p2 : returner2) {
            for (Position p : board_.get_pawn(other_player(turn_))) {
                if (board_[p] == Player::light) {
                    Position position_test = {p.x + 1, p.y - 1};
                    if (board_.good_position(position_test) && position_test == p2) {
                        returner[p2] = false;
                    }
                    position_test = {p.x - 1, p.y - 1};
                    if (board_.good_position(position_test) && position_test == p2) {
                        returner[p2] = false;
                    }
                } else {
                    Position position_test = {p.x + 1, p.y + 1};
                    if (board_.good_position(position_test) && position_test == p2) {
                        returner[p2] = false;
                    }
                    position_test = {p.x - 1, p.y + 1};
                    if (board_.good_position(position_test) && position_test == p2) {
                        returner[p2] = false;
                    }
                }
            }
        }
        for (Move m3 : other_moves) {
            for (Position p2 : returner2) {
                if (board_.get_piece(m3.first) == Piece::pawn) {
                    if (board_[m3.first] == Player::light) {
                        Position position_test = {m3.first.x + 1, m3.first.y - 1};
                        if (board_.good_position(position_test) && position_test == p2) {
                            returner[p2] = false;
                        }
                        position_test = {m3.first.x - 1, m3.first.y - 1};
                        if (board_.good_position(position_test) && position_test == p2) {
                            returner[p2] = false;
                        }
                    } else {
                        Position position_test = {m3.first.x + 1, m3.first.y + 1};
                        if (board_.good_position(position_test) && position_test == p2) {
                            returner[p2] = false;
                        }
                        position_test = {m3.first.x - 1, m3.first.y + 1};
                        if (board_.good_position(position_test) && position_test == p2) {
                            returner[p2] = false;
                        }
                    }
                } else {
                    if (board_.get_piece(m3.first) == Piece::rook) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::bishop) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::queen) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::knight) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    } else if (board_.get_piece(m3.first) == Piece::king) {
                        for (Position p5 : m3.second) {
                            if (p5 == p2) {
                                returner[p2] = false;
                            }
                        }
                    }
                }
            }
        }
        if (!returner.empty()) {
            next_moves_[king_finder] = returner;
        }
        for (Move m5 : other_moves) {
            iterator = 0;
            target.clear();
            illegal.clear();
            test_check = false;
            if (board_.get_piece(m5.first) == Piece::rook) {
                if (m5.first.x == king_finder.x) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.x == king_finder.x) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                    if (iterator > 0) {
                        for (Position p7 : target) {
                            Position_set tester = rook_moves_(p7, other_player(turn_));
                            for (Position p6 : tester) {
                                if (p6 == king_finder) {
                                    test_check = true;
                                }
                            }
                            if (test_check) {
                                if (targeter[p7].empty()) {
                                    for (Position p9 : possible_moves_(p7, turn_)) {
                                        if (m5.first.x == king_finder.x) {
                                            if (p9.x == m5.first.x) {
                                                illegal[p9] = true;
                                            }
                                        } else if (m5.first.y == king_finder.y) {
                                            if (p9.y == m5.first.y) {
                                                illegal[p9] = true;
                                            }
                                        }
                                    }
                                    targeter[p7] = illegal;
                                    if (targeter[p7].empty()) {
                                        more_illegal[p7] = true;
                                    } else {
                                        more_illegal[p7] = false;
                                    }
                                } else {
                                    more_illegal[p7] = true;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        }
                    }
                } else if (m5.first.y == king_finder.y) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.y == king_finder.y) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                    if (iterator > 0) {
                        for (Position p7 : target) {
                            Position_set tester = rook_moves_(p7, other_player(turn_));
                            for (Position p6 : tester) {
                                if (p6 == king_finder) {
                                    test_check = true;
                                }
                            }
                            if (test_check) {
                                if (targeter[p7].empty()) {
                                    for (Position p9 : possible_moves_(p7, turn_)) {
                                        if (m5.first.x == king_finder.x) {
                                            if (p9.x == m5.first.x) {
                                                illegal[p9] = true;
                                            }
                                        } else if (m5.first.y == king_finder.y) {
                                            if (p9.y == m5.first.y) {
                                                illegal[p9] = true;
                                            }
                                        }
                                    }
                                    targeter[p7] = illegal;
                                    if (targeter[p7].empty()) {
                                        more_illegal[p7] = true;
                                    } else {
                                        more_illegal[p7] = false;
                                    }
                                } else {
                                    more_illegal[p7] = true;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        }
                    }
                }
            } else if (board_.get_piece(m5.first) == Piece::bishop) {
                if (abs(king_finder.x - m5.first.x) == abs(king_finder.y - m5.first.y)) {
                    for (Position p5 : m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && abs(king_finder.x - p5.x)
                                                                        == abs(king_finder.y - p5.y)) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                }
                if (iterator > 0) {
                    for (Position p7 : target) {
                        Position_set tester = bishop_moves_(p7, other_player(turn_));
                        for (Position p6 : tester) {
                            if (p6 == king_finder) {
                                test_check = true;
                            }
                        }
                        if (test_check) {
                            if (targeter[p7].empty()) {
                                for (Position p9 : possible_moves_(p7, turn_)) {
                                    if (m5.first.x > king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x > king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    }
                                }
                                targeter[p7] = illegal;
                                if (targeter[p7].empty()) {
                                    more_illegal[p7] = true;
                                } else {
                                    more_illegal[p7] = false;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        } else {
                            more_illegal[p7] = true;
                        }
                    }
                }
            } else if (board_.get_piece(m5.first) == Piece::queen) {
                if (m5.first.x == king_finder.x) {
                    for (Position p5: m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.x == king_finder.x) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                } else if (m5.first.y == king_finder.y) {
                    for (Position p5: m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king && p5.y == king_finder.y) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                } else if (abs(king_finder.x - m5.first.x) == abs(king_finder.y - m5.first.y)) {
                    for (Position p5: m5.second) {
                        if (board_[p5] == turn_ && board_.get_piece(p5) != Piece::king &&
                            abs(king_finder.x - p5.x) == abs(king_finder.y - p5.y)) {
                            iterator++;
                            target[p5] = true;
                        }
                    }
                }
                if (iterator > 0) {
                    for (Position p7 : target) {
                        Position_set tester = queen_moves_(p7, other_player(turn_));
                        for (Position p6 : tester) {
                            if (p6 == king_finder) {
                                test_check = true;
                            }
                        }
                        if (test_check) {
                            if (targeter[p7].empty()) {
                                for (Position p9 : possible_moves_(p7, turn_)) {
                                    if (m5.first.x > king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y > king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y >= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x < king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x <= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x > king_finder.x && m5.first.y < king_finder.y) {
                                        if (p9.x >= m5.first.x && p9.y <= m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.x == king_finder.x) {
                                        if (p9.x == m5.first.x) {
                                            illegal[p9] = true;
                                        }
                                    } else if (m5.first.y == king_finder.y) {
                                        if (p9.y == m5.first.y) {
                                            illegal[p9] = true;
                                        }
                                    }
                                }
                                targeter[p7] = illegal;
                                if (targeter[p7].empty()) {
                                    more_illegal[p7] = true;
                                } else {
                                    more_illegal[p7] = false;
                                }
                            } else {
                                more_illegal[p7] = true;
                            }
                        } else {
                            more_illegal[p7] = true;
                        }
                    }
                }
            }
        }
        for (Move m11 : targeter) {
            next_moves_[m11.first] = m11.second;
        }
        for (Position p8 : more_illegal) {
            next_moves_[p8] = {};
        }
    }
}

bool
Model::advance_turn_()
{
    turn_ = other_player(turn_);
    compute_next_moves_();
    return !next_moves_.empty();
}

void
Model::set_game_over_(bool stalemate)
{
    if (stalemate) {
        winner_ = Player::neither;
    } else {
        winner_ = other_player(turn_);
    }
    turn_ = Player::neither;
}

void
Model::really_play_move_(Move move, Position pos_two, Board* board)
{
    Piece piece = board_.get_piece(move.first);
    board_[pos_two] = (*board)[move.first];
    board_[move.first] = Player::neither;
    Position_set piecer;
    Position_set piecer_fake;
    piecer[pos_two] = true;
    piecer_fake[move.first] = true;
    board_.set_all_piece(piecer_fake, Piece::neither);
    board_.set_all_piece(piecer, piece);
    recent_move_ = pos_two;
    for (int i = 0; i < board_.all_positions().height; i++) {
        if (board_[{i, 0}] == Player::light) {
            if (board_.get_piece({i, 0}) == Piece::pawn) {
                Position_set pieces;
                pieces[{i, 0}] = true;
                board_.set_all_piece(pieces, Piece::queen);
            }
        }
        if (board_[{i, 7}] == Player::dark) {
            if (board_.get_piece({i, 7}) == Piece::pawn) {
                Position_set pieces;
                pieces[{i, 7}] = true;
                board_.set_all_piece(pieces, Piece::queen);
            }
        }
    }
    if (!advance_turn_()) {
        if (turn_ == Player::light && white_under_check_) {
            set_game_over_(false);
        } else if (turn_ == Player::dark && black_under_check_) {
            set_game_over_(false);
        } else {
            set_game_over_(true);
        }
    }
}
