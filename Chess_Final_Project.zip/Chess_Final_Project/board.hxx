/*******************************************/
/*** DO NOT CHANGE ANYTHING IN THIS FILE ***/
/*******************************************/

#pragma once

#include "player.hxx"
#include "move.hxx"
#include "piece.hxx"

#include <ge211.hxx>

#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

/// Represents the state of the board.
class Board
{
public:
    //
    // HELPFUL TYPE ALIASES
    //

    /// Board dimensions will use `int` coordinates.
    using Dimensions = ge211::Dims<int>;

    /// Board positions will use `int` coordinates.
    using Position = ge211::Posn<int>;

    /// Board rectangles will use `int` coordinates.
    using Rectangle = ge211::Rect<int>;

    // Defined and documented below.
    class reference;

private:
    //
    // PRIVATE DATA MEMBERS
    //

    Dimensions dims_;
    Position_set light_;
    Position_set dark_;
    Position_set pawn_;
    Position_set knight_;
    Position_set bishop_;
    Position_set rook_;
    Position_set queen_;
    Position_set king_;
    // INVARIANT: (light_ & dark_).empty()

public:
    //
    // PUBLIC CONSTRUCTOR & FUNCTION MEMBERS
    //

    /// Constructs a board with the given dimensions.
    ///
    /// ## Errors
    ///
    ///  - Throws `ge211::Client_logic_error` if either dimension is less
    ///    than 2 or greater than 8.
    explicit Board(Dimensions dims);

    /// Returns the same `Dimensions` value passed to the
    /// constructor.
    Dimensions dimensions() const;

    /// Returns whether the given position is in bounds.
    bool good_position(Position) const;

    /// Returns the `Player` stored at `pos`.
    ///
    /// ## Errors
    ///
    ///  - throws `ge211::Client_logic_error` if `!good_position(pos)`.
    Player operator[](Position pos) const;


    //
    // PUBLIC CONSTRUCTOR & FUNCTION MEMBERS
    //

    /// Returns a reference to the `Player` stored at `pos`. This can
    /// be assigned to update the board:
    ///
    /// ```
    /// // Light player plays at (3, 4)
    /// board[{3, 4}] = Player::light;
    /// ```
    ///
    /// ## Errors
    ///
    ///  - throws `ge211::Client_logic_error` if `!good_position(pos)`.
    reference operator[](Position pos);

    /// Stores the given player in all the positions in the given set.
    /// For example,
    ///
    /// ```
    /// // Sets three positions to dark:
    /// Position_set positions{{0, 0}, {1, 1}, {2, 2}};
    /// board.set_all(positions, Player::dark);
    /// ```
    ///
    /// ## Errors
    ///
    ///  - behavior is undefined if any positions in the `Position_set`
    ///    are out of bounds.
    void set_all(Position_set, Player);

    /// Stores the given piece in all the positions in the given set.
    /// ## Errors
    /// - behavior is undefined if any positions in the 'Position_set'
    ///   are out of bounds.
    void set_all_piece(Position_set, Piece);

    /// Returns the given piece from the position.
    /// ## Errors
    Piece get_piece(Position) const;

    /// Counts the number of occurrences of the given player in the board.
    size_t count_player(Player) const;

    /// Returns a rectangle containing all the positions of the board. This
    /// can be used to iterate over the positions:
    ///
    /// ```
    /// for (Position pos : a_board.all_positions()) {
    ///     ... a_board[pos] ...;
    /// }
    /// ```
    ///
    /// Note that `Rectangle`s are considered to be closed on the top
    /// and left, but open on the bottom and right. The iterator will visit
    /// the correct positions for the board.
    Rectangle all_positions() const;

    /// Returns a reference to a `std::vector` containing all eight "unit
    /// direction vectors". In Python notation, these are:
    ///
    /// ```python
    /// { Dims(dx, dy)
    ///       for dx in [-1, 0, 1]
    ///           for dy in [-1, 0, 1]
    ///               if dx or dy }
    /// ```
    static std::vector<Dimensions> const& all_directions();

    /// Returns a reference to a 'std::vector' containing all eight potential
    /// knight move directions.
    std::vector<Dimensions> knight_directions() const;

    /// Equality for boards.
    friend bool operator==(Board const&, Board const&);

    /// The function initial_state sets up the initial values of the objects in the board
    void initial_state();

    /// The function get_king gets the position of the player's king in the current board
    Position get_king(Player turn);

    /// The function get_player_color gets all the positions of the pieces that the player
    /// current has in the board
    Position_set get_player_color(Player turn);

    /// The function gets all the pawns that the player currently
    /// has in the board
    Position_set get_pawn(Player turn);

private:
    //
    // PRIVATE HELPER FUNCTION MEMBERS
    //

    /// returns which player owns the piece in the given position
    Player get_(Position where) const;

    /// sets who owns the piece in the given position
    void set_(Position where, Player who);

    /// checks the bound of the position in regards to the board dimension
    void bounds_check_(Position where) const;

    /// gets the piece from the given position
    Piece get_piece_(Position where) const;

    /// Given a position, sets the given chess piece there
    void set_piece_(Position where, Piece what);

#ifdef CS211_TESTING
    // When this class is compiled for testing, members of a struct named
    // Test_access will be allowed to access private members of this class.
    friend struct Test_access;
#endif
};


//
// FREE FUNCTIONS FOR WORKING WITH THE CLASS
//

/// Inequality for boards.
bool
operator!=(Board const&, Board const&);

/// Board printing, suitable for debugging.
std::ostream&
operator<<(std::ostream&, Board const&);


//
// HELPER CLASSES
//

/// Class returned by `operator[](Position)` that simulates
/// an assignable reference to a `Posn<int>`. This is what allows
/// you to write
///
///     board[pos] = player;
///
/// to place `player` at `pos`.
///
/// The definition of the class follows this definition of the
/// `Board` class.
class Board::reference
{
    Board& board_;
    Position pos_;

public:
    /// Assigns the value of `that` to the object of `this`.
    reference& operator=(reference const&) noexcept;

    /// Assigns to the object of the reference.
    reference& operator=(Player) noexcept;

    /// Assigns to the object of the reference.
    reference& operator=(Piece) noexcept;

    /// Returns the value of the reference.
    operator Player() const noexcept;

private:
    friend class Board;

    reference(Board&, Position) noexcept;
};



